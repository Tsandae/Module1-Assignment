# Step 1: Create a list of 400 workers dynamically
num_workers = 400
workers = []

for i in range(num_workers):
    # Create worker data: name, salary, gender
    worker = {
        "name": "Worker_" + str(i + 1),
        "salary": 5000 + (i % 30) * 1000,  
        "gender": "Male" if i % 2 == 0 else "Female" 
    }
    workers.append(worker)

# Step 3: Use a for loop to generate payment slips for each worker
for worker in workers:
    try:
        # Step 4: Implement the conditional statements
        if worker["salary"] > 10000 and worker["salary"] < 20000:
            worker["level"] = "A1"
        elif worker["salary"] > 7500 and worker["salary"] < 30000 and worker["gender"] == "Female":
            worker["level"] = "A5-F"
        else:
            worker["level"] = "Not Specified"

        # Print the payment slip for each worker
        print("Payment Slip: Name:", worker["name"], 
              ", Salary: $", worker["salary"], 
              ", Gender:", worker["gender"], 
              ", Level:", worker["level"])

    # Step 5: Add exception handling to handle potential errors
    except Exception as e:
        print("An error occurred for",worker["name"], ":", e)
